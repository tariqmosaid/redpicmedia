<!DOCTYPE html>
<html class="no-js" lang="ar">

<head>

    <!-- Meta Data -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="facebook-domain-verification" content="lfkgj15gm5hf3t2y78rvqnv80edrbx" />
  
  <!-- Meta Pixel Code -->
<script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '689310002425837');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=689310002425837&ev=PageView&noscript=1"
/></noscript>
<!-- End Meta Pixel Code -->
  
  
  
  
  
    <title> MediaMan Marketing Agency </title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="assets/media/favicon.png?v=1.0">
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/vendor/font-awesome.css">
    <link rel="stylesheet" href="assets/css/vendor/slick.css">
    <link rel="stylesheet" href="assets/css/vendor/slick-theme.css">
    <link rel="stylesheet" href="assets/css/vendor/sal.css">
    <link rel="stylesheet" href="assets/css/vendor/magnific-popup.css">
    <link rel="stylesheet" href="assets/css/vendor/green-audio-player.min.css">

    <!-- Site Stylesheet -->
    <link rel="stylesheet" href="assets/css/app.css?ver=1.1.1">
    <link rel="stylesheet" href="assets/avenir/stylesheet.css">
    <link rel="stylesheet" href="assets/css/custom.css?v=1.012345">
    <link rel="stylesheet" href="assets/css/responsive.css?v=1.012345">

    <script src="https://apps.elfsight.com/p/platform.js" defer></script>
    <div class="elfsight-app-36517035-efd0-4e53-912c-5a163489e187"></div>
    
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-129523657-3"></script>
    <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
    
      gtag('config', 'UA-129523657-3');
    </script>
    
    <style>
        .mainmenu>.menu-item-has-children>a::after {
            right: inherit;
            left: -20px;
        }
        
        .mainmenu>.menu-item-has-children>a {
            margin-left: 20px;
            margin-right: initial;
        }
        
        .mainmenu>.menu-item-has-children .axil-submenu {
            right: 0;
            left: initial;
        }
    </style>


</head>
</head>

<body class="sticky-header">
  
<style>
    p.phone_n {
        direction: ltr !important;
        text-align: right;
    }
    h6.sub-cat {
        padding-right: 30px;
    }
    p {
        text-align: justify;
    }
</style>

    <div id="main-wrapper" class="main-wrapper">


    <header class="header axil-header header-style-1" dir='rtl'>
    <div id="axil-sticky-placeholder"></div>
    <div class="axil-mainmenu">
        <div class="container">
            <div class="header-navbar">
                <div class="header-logo">
                    <a href="/"><img class="light-version-logo" src="/assets/logo-01.png"alt="logo"></a>
                    <a href="/"><img class="dark-version-logo" src="/assets/logo-01.png" alt="logo"></a>
                    <a href="/"><img class="sticky-logo" src="/assets/logo-01.png" alt="logo"></a>
                </div>
                <div class="header-main-nav">
                    <!-- Start Mainmanu Nav -->
                    <nav class="mainmenu-nav" id="mobilemenu-popup" aria-modal="true" role="dialog">
                        <div class="d-block d-lg-none">
                            <div class="mobile-nav-header">
                                <div class="mobile-nav-logo">
                                    <a href="index-1.html">
                                        <img class="light-mode" src="/assets/logo-01.png" alt="Site Logo">
                                        <img class="dark-mode" src="/assets/logo-01.png" alt="Site Logo">
                                    </a>
                                </div>
                                <button class="mobile-menu-close" id="menu-mobile-close" data-bs-dismiss="offcanvas">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <ul class="mainmenu">
                            <li><a href="/"> الرئيسية </a></li>
                            <li><a href="about"> من نحن </a></li>
                            <li class="menu-item-has-children">
                                <a href="javascript:void(0);">خدماتنا</a>
                                <ul class="axil-submenu">
                                    <li><a href="branding">بناء الهوية التجارية و التصميم</a></li>
                                    <li><a href="development-web">تصميم و برمجة المواقع </a></li>
                                    <li><a href="digital-advertising">الحملات الإعلانية</a></li>
                                    <li><a href="video-production">الفيديوهات التسويقية</a></li>
                                    <li><a href="social-media-managemet">ادارة مواقع التواصل الاجتماعي</a></li>
                                </ul>
                            </li>
                            <!--li><a href="works"> أعمالنا </a></li-->
                            <li><a href="contact">تواصل معنا</a></li>
                            <li class="flag-li">  <a href="https://fr.mediaman.ma/"> Fr <img class="lang-flag" src="/fr.png" alt="">  </a> </li>
                        </ul>
                    </nav>
                    <!-- End Mainmanu Nav -->
                </div>
                <div class="header-action">
                    <ul class="list-unstyled">
                        <li class="mobile-menu-btn sidemenu-btn d-lg-none d-block">
                            <button class="btn-wrap" id="menu-mobile" data-bs-toggle="offcanvas" data-bs-target="#mobilemenu-popup">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</header>


        <!--=====================================-->
        <!--=       Breadcrumb Area Start       =-->
        <!--=====================================-->
        <div class="breadcrum-area" dir="rtl">
            <div class="container">
                <div class="breadcrumb">
                    <ul class="list-unstyled">
                       
                        <li><a href="/">الرئيسية</a></li>
                        <li class="active"> 
                            سياسة الخصوصية 
                        </li>
                        </ul>
                        <h1 class="title h2">
                                سياسة الخصوصية 
                        </h1>
                </div>
            </div>
            <ul class="shape-group-8 list-unstyled">
                <li class="shape shape-1" data-sal="slide-right" data-sal-duration="500" data-sal-delay="100">
                    <img src="assets/media/others/bubble-9.png" alt="Bubble">
                </li>
                <li class="shape shape-2" data-sal="slide-left" data-sal-duration="500" data-sal-delay="200">
                    <img src="assets/media/others/bubble-11.png" alt="Bubble">
                </li>
                <li class="shape shape-3" data-sal="slide-up" data-sal-duration="500" data-sal-delay="300">
                    <img src="assets/media/others/line-4.png" alt="Line">
                </li>
            </ul>
        </div>
        <!--=====================================-->
        <!--=    Privacy Policy Area Start      =-->
        <!--=====================================-->
        <section class="section-padding privacy-policy-area" dir="rtl">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-10">
                        <div class="privacy-policy-content">
                            
                            <p> نحن في ميديا مان معنيون بالحفاظ على خصوصيتك وسرية معلوماتك، إن سياسة الخصوصية هذه تشرح وتبين كيف تقوم ميديا مان بجمع واستخدام ومشاركة المعلومات الخاصة بك كمستخدم للموقع الإلكتروني الخاص بميديا مان ” الموقع الإلكتروني” (www.mediaman.ma ) أو المعلومات التي تزودنا أنت بها عند زيارتك للموقع الإلكتروني أو عند اشتراكك في إحدى الخدمات التي نقدمها. </p>
                            <p> إن الغرض الأساسي من موقعنا الالكتروني هو تقديم خدمات مدفوعة في مجال تصميم مواقع الانترنت والتصاميم الطباعية وتصاميم الهوية التجارية. إن هذه السياسة لا تشمل المعلومات التي نقوم بجمعها عن طريق التواصل الفعلي “offline” أو من خلال أطراف أخرى يتم التعاون معهم من خلال الموقع الإلكتروني. </p>

                            <h4> المعلومات التي نجمعها عنك وكيف نستخدمها </h4>
                            <h6 class="sub-cat">معلومات شخصية:</h6>
                            <p> والمقصود بالمعلومات الشخصية مثل الاسم والبريد الإلكتروني الخاص بك ورقم هاتفك …. الخ. نحن نجمع هذه المعلومات عندما تقوم أنت بتزويدنا بها من خلال اشتراكك لتلقي خدمة نحن نقدمها أو عند رغبتك بالتواصل معنا، أو عندما تقوم بتعبأة استبيان نقوم نحن بتحميله على الموقع الإلكتروني، أو عند استعمالك لأي أداة دفع الكترونية، أو إذا تم الإعلان عن شواغر وظيفية لدى ميديا مان وتطلب منك ذلك إرسال سيرتك الذاتية وتزويدنا بمعلومات شخصية عنك، أو عند رغبتك بالاتصال بميديا مان للاستفسار عن أي موضوع متعلق بالموقع الإلكتروني أو الخدمات التي نقدمها. 
                                <br>
                                إن معظم الخدمات الموجودة على موقعنا الإلكتروني تتطلب منك القيام بتزويدنا بقدر معين من المعلومات الشخصية عنك لغايات تفعيل هذه الخدمات، كما قد يكون هنالك حقولا إضافية تطلب منك معلومات تكون بمثابة معلومات إضافية في حال أنك رغبت بتزويدنا بها، ومثل هذه الحقول تكون طوعية وليست إجبارية لتفعيل الخدمة.
                                <br>
                                بالإشارة لما سبق، فإن عدم تزويدك بالمعلومات الضرورية واللازمة لتفعيل خدمة معينة لا يمكننا بأي حال من الأحوال من القيام بتفعيل هذه الخدمات.
                                <br>
                                إننا في ميديا مان قد نجمع معلومات عن عنوان بروتوكول الإنترنت الخاص بك “IP” address وذلك لتجنب الكثير من المشاكل التقنية التي قد تواجهنا عند تزويدك بخدماتنا.
                                <br>
                                إنك وبعد أن قرأت طبيعة المعلومات الشخصية التي نجمعها عنك، فإنك تسمح لنا باستخدام المعلومات الشخصية الخاصة بك والتي قمت أنت بتزويدنا بها وذلك لغايات الاشتراك بالموقع الإلكتروني وتزويدك بالخدمات التي نقدمها.
                            </p>
                            <h6 class="sub-cat"> معلومات أخرى يتم جمعها ” ليست شخصية”: </h6>
                            <p>
                                تقوم ميديا مان أو طرف آخر مرتبط معنا بصيغة تعاقدية ( مثل مزودي و مشغلي خدمات الإنترنت و الخوادم) بجمع و تحليل العديد من المعلومات عن مستخدمي و زائري الموقع الإلكتروني بطريقة أوتوماتيكية و تلقائية ، وعلى سبيل المثال لا الحصر ؛ نقوم بجمع بيانات و معلومات عن نوع المتصفح الخاص بك و نوع نظام التشغيل الخاص بجهازك الحاسوب وطبيعة تصفحك للموقع الإلكتروني و الصفحات التي قمت بزيارتها و تاريخ الزيارة للموقع الإلكتروني و مدة بقائك على الموقع الإلكتروني و غيرها من المعلومات التي تستخدم لغايات إحصائية و تحليلية بحته .
                                <br>
                                إن هذه المعلومات المشار إليها سابقا، يتم جمعها بشكل مجمل دون النظر لمستخدم بعينه، كما أنها لا تحتوي معلومات شخصية عن المستخدم أو الزائر للموقع الإلكتروني.
                                <br>
                                نحن لا نسعى بأي حال من الأحوال لجمع معلومات شخصية أكثر مما هو ضروري ومعقول ويتناسب مع طبيعة الخدمة التي سنقوم بتزويدك بها.
                            </p>
                            
                            <h4>الأطفال</h4>
                            <p>
                                نحن في ميديا مان نحرص وبشكل كبير على حماية خصوصية الأطفال ونشجع الآباء وأولياء الأمور على القيام بدور فاعل تجاه الأنشطة التي يمارسها أطفالهم على شبكة الإنترنت.
                                <br>
                                إذا كنت تحت السن القانوني الذي يمكنك من استخدام الإنترنت بدون وصاية، فأنت مسؤول عن الحصول على موافقة من الوالدين / ولي الأمر إذا كنت ترغب بالحصول على أي من الخدمات التي يقدمها موقعنا الالكتروني.
                            </p>

                            <h4>الإفصاح عن المعلومات</h4>
                            <p> نحن لن نقوم بالإفصاح عن المعلومات الشخصية الخاصة بك لأي جهة او طرف خارجي إلا في حدود ما تم توضيحه سابقا في هذه السياسة وفي الحالات التالية: </p>
                            <ul>
                                <li>إذا فرض علينا ذلك بموجب القانون أو اللوائح أو الأنظمة و التعليمات الصادرة من جهات حكومية محلية أو إقليمية أو دولية ، أو للتعاون مع أي تحقيق تجريه سلطة أو هيئة حكومية أو لإنفاذ أمر قضائي و إنفاذا للقانون.</li>
                                <li>إذا تطلب ذلك حماية حقوق و سمعة و ممتلكات ميديا مان او غيرها.</li>
                                <li>للدفاع عن حقوقنا المالية أو القانونية أو لتأكيد و تنفيذ التزامات الغير تجاهنا.</li>
                                <li>إذا كان مطلوب الإفصاح عن ذلك وفقا للمعايير المهنية أو تبادل المعلومات.</li>
                                <li>تنفيذا لأي اتفاقية أو عقد موقع بينك و بين ميديا مان بما في ذلك سياسة الخصوصية هذه و شروط الاستخدام.</li>
                                <li>تنفيذا لأي اتفاقية تشمل تبادل المعلومات مع شركات أو منظمات لأغراض الحماية من الغش و الحد من مخاطر الائتمان.</li>
                                <li>في حال قررت الشركة بيع كل أو جزء من أسهمها أو الأصول أو قررت الدخول في اندماج ، حيث نحتفظ بحق تحديد المعلومات المراد الإفصاح عنها و طبيعتها لتكون ضمن الأصول المنقولة او الباقية في حوزتنا.</li>
                                <li>لتزويد أي طرف آخر بالمعلومات الغير شخصية عن الزائرين للموقع الإلكتروني او مستخدمي خدماتنا و ذلك لغايات إحصائية و تحليلية.</li>
                            </ul>

                            <h4>الاحتفاظ بالمعلومات</h4>
                            <p> نحن نحتفظ بالمعلومات الشخصية وغير الشخصية عن المستخدمين والزوار للموقع الإلكتروني طالما أنها لازمة لتوفير خدماتنا للمستخدمين للموقع الإلكتروني.
                                <br>
                                وسنبقى محتفظين بهذه المعلومات ويحق لنا استخدامها بالطريقة التي نراها مناسبة والوقت الذي نحدده وذلك لإنفاذ الاتفاقيات المبرمة مع المستخدمين للموقع الإلكتروني وإنفاذا للقانون ولفض أي نزاع مع أي طرف آخر وللدفاع عن حقوقنا. 
                            </p>

                            <h4>كيفية استخدام المعلومات التي نملكها</h4>
                            <ul>
                                <li>للتأكد من فاعلية الخدمات التي نقدمها و أنها تتناسب مع جهاز الكمبيوتر الخاص بك او هاتفك المحمول أو أي جهاز آخر تستخدمه.</li>
                                <li>لتوفير المعلومات و الخدمات التي تطلبها منا.</li>
                                <li>لتنفيذ التزاماتنا الناشئة عن العقود المبرمة بيننا و بين المستخدمين للموقع الإلكتروني و لتحصيل حقوقنا المالية و القانونية.</li>
                                <li>إذا كنت تدفع مقابل الخدمة التي تتلقاها من خلال استخدامك بطاقات الائتمان أو أي بطاقة الكترونية ، فسوف نحيل بيانات بطاقتك إلى شركة البطاقات التي تتعامل انت معها.</li>
                                <li>لكي يسمح لك الموقع الإلكتروني بالمشاركة بالميزات التفاعلية لخدماتنا و ذلك عند تفعيلك لهذه الخدمات.</li>
                                <li>لإعلامك عن أي تغيير او تعديل أو اضافة على خدماتنا التي نقدمها من خلال الموقع الإلكتروني.</li>
                                <li>إذا طلبت منا التواصل معك من خلال أي خيار موجود على الموقع الإلكتروني او من خلال أي نموذج غايته التواصل معنا أو من خلال أي خيار من متطلباته إعادة الاتصال بك.</li>
                            </ul>
                            
                            <h4>تعديل المعلومات الخاصة بالمستخدمين</h4>
                            <p> إذا كنت تعتقد أننا نحتفظ بمعلومات خاطئة عنك او ترغب بتغيير وتعديله هذه المعلومات، فإنه لك الحق بتعديلها بالكيفية والوقت الذي تراه مناسبا، كما يمكنك مراسلتنا مباشرة على البريد الإلكتروني التالي لإجراء أي تعديل: <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="ff9c90918b9e9c8bbf929a9b969e929e91d1929e">[email&#160;protected]</a> </p>

                            <h4>أمن المعلومات</h4>
                            <p> نعمل جاهدين في ميديا مان على حماية الموقع الإلكتروني والمستخدمين من الدخول الغير مصرح به أو أي تعديل غير مصرح به أو إفشاء أو اتلاف للمعلومات التي بحوزتنا، لذلك يتم تخزين جميع المعلومات التي تقدمها لنا على خوادم آمنة لدينا، ويتم تشفير معاملات الدفع الإلكتروني مقابل الخدمات باستخدام طبقة المقابس الآمنة “SSL”، وذلك من أجل حماية سرية معلوماتك الشخصية ومعلومات بطاقة الائتمان الخاصة بك. </p>
                                إن وصولك لحسابك الخاص على الموقع الإلكتروني يكون من خلال كلمة المرور واسم المستخدم الخاص بك والذي تختاره. ويتم تشفير كلمة المرور حرصا على حماية خصوصيتك.
                                <br>
                                إننا في ميديا مان نوصي مستخدمي الموقع الإلكتروني بعدم إفشاء كلمة المرور الخاصة بهم لأي طرف آخر، كما اننا ننصحكم بتغيير كلمة المرور بشكل دوري واستخدام الأحرف والأرقام عند إنشاء كلمة مرور جديدة، وفي حال كنت تتشارك مع شخص آخر جهازك الحاسوب، نرجو منك تسجيل الخروج من حسابك بعد الانتهاء وذلك لضمان تصفح آمن على صفحات الويب.
                                <br>
                                إننا في ميديا مان غير مسؤولين وبأي شكل من الأشكال عن أي تصرف ناتج عن إهمال المستخدم بالحفاظ على كلمة المرور الخاصة به.
                                <br>
                                الرجاء إبلاغنا فورا إذا تم سرقة كلمة المرور الخاصة بك و / أو اسم المستخدم أو اعتقدت أن شخص ما تسلل الى حسابك الشخصي وذلك من خلال مخاطبتنا على البريد الإلكتروني التالي: <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="9ffcf0f1ebfefcebdff2fafbf6fef2fef1b1f2fe">[email&#160;protected]</a>
                                <br>
                                أو الاتصال بنا مباشرة عبر الهاتف من خلال الرقم التالي:
                            <p>
                            <p class="phone_n"> 05 28 21 57 07 </p>

                            <h4> الروابط الخاصة بمواقع الكترونية خارجية </h4>
                            <p> 
                                إن هذه السياسة لا تتناول ولا تشمل سوى الاستخدام والإفصاح عن المعلومات التي نجمعها عن مستخدمي خدماتنا من خلال الموقع الإلكتروني والزوار للموقع الإلكتروني سواء أكانت شخصية او غير شخصية. لذلك نرجو التنويه ان الموقع الإلكتروني الخاص بميديا مان قد يحتوي على روابط في عدة صفحات تحيل المستخدم أو الزائر إلى مواقع الكترونية خارجية والتي من شأنها أن تقوم بجمع معلومات عنك والإفصاح عنها بطريقة مختلفة عن الموقع الإلكتروني الخاص بميديا مان.
                                <br>
                                نحن في ميديا مان غير مسؤولين عن جمع او استخدام او الإفصاح عن أية معلومات يقوم بها موقع الكتروني آخر له رابط في الموقع الإلكتروني الخاص بميديا مان. ونوصي عملائنا ومستخدمي الموقع الإلكتروني بقراءة سياسة الخصوصية الخاصة بكل موقع تقومون بزيارته.
                                <br>
                                كما ننوه أننا لسنا مسؤولين عن أية معلومات ترد على صفحات تلك المواقع الإلكترونية التي لها روابط في الموقع الإلكتروني الخاص بنا.
                            </p>

                            <h4> تعديل وتغيير سياسة الخصوصية </h4>
                            <p>
                                يحق لميديا مان إجراء أي تعديل أو تغيير أو اضافة او حذف على هذه السياسة وبالكيفية والوقت الذي نراه مناسبا.
                                <br>
                                ونود التنويه بأننا نقوم بإظهار تاريخ آخر تعديل على هذه السياسة ونعلن عن ذلك في الصفحة الرئيسية بالموقع الإلكتروني ولمدة أسبوع من تاريخ التعديل، ويجب على المستخدمين مراجعة هذه السياسة من وقت لآخر لتتبع أي تعديلات عليها.
                                <br>
                                كما ننوه بأننا غير مسؤولين عن عدم مراجعتك لهذه السياسة قبل استخدام وتصفح الموقع الإلكتروني وإن قراءة هذه السياسة من قبل مستخدمي ومتصفحي الموقع الإلكتروني هو اقرار كامل واعتراف منهم بكل ما ورد بهذه السياسة واتفاق على جميع ما ورد فيها.
                                <br>
                                الاتصال بنا
                                <br>
                                نحن نرحب بآرائكم واستفساراتكم فيما يتعلق بهذه السياسة. فإذا كنت ترغب بالاتصال معنا بخصوص سياسة الخصوصية، نرجو منك مراسلتنا على البريد الإلكتروني التالي: <a href="/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="50333f3e24313324103d353439313d313e7e3d31">[email&#160;protected]</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>



        
<section class="section call-to-action-area call-to-action-footer" dir="lrt" id="call-us">
    <div class="container">
        <div class="call-to-action">
            <div class="section-heading heading-light">
                <span class="subtitle text-center">
                متشوّقون للعمل معًا!
                </span>
                <h2 class="title text-center">
                    نود أن نسمع عن مشروعك!
                </h2>

                
                
                    <a href="/contact" class="axil-btn btn-large btn-fill-white">   تواصل معنا </a>

                
            </div>
            <div class="thumbnail">
                <div class="larg-thumb" data-sal="zoom-in" data-sal-duration="600" data-sal-delay="100">
                    <img class="paralax-image" src="assets/media/others/chat-group.png" alt="Chat">
                </div>
                <ul class="list-unstyled small-thumb">
                    <li class="shape shape-1" data-sal="slide-right" data-sal-duration="800"
                        data-sal-delay="400">
                        <img class="paralax-image" src="assets/media/others/laptop-poses.png" alt="Laptop">
                    </li>
                    <li class="shape shape-2" data-sal="slide-left" data-sal-duration="800"
                        data-sal-delay="300">
                        <img class="paralax-image" src="assets/media/others/bill-pay.png" alt="Bill">
                    </li>
                </ul>
            </div>
        </div>
    </div>
    <ul class="list-unstyled shape-group-9">
        <li class="shape shape-1"><img src="assets/media/others/bubble-12.png" alt="Comments"></li>
        <li class="shape shape-2"><img src="assets/media/others/bubble-16.png" alt="Comments"></li>
        <li class="shape shape-3"><img src="assets/media/others/bubble-13.png" alt="Comments"></li>
        <li class="shape shape-4"><img src="assets/media/others/bubble-14.png" alt="Comments"></li>
        <li class="shape shape-5"><img src="assets/media/others/bubble-16.png" alt="Comments"></li>
        <li class="shape shape-6"><img src="assets/media/others/bubble-15.png" alt="Comments"></li>
        <li class="shape shape-7"><img src="assets/media/others/bubble-16.png" alt="Comments"></li>
    </ul>
</section>






<style>
    .step2 {
    text-align: center;
    line-height: 35px;
    margin-bottom: 45px;
    font-size: 18px;
}
p.orrr {
    margin: 0;
    text-align: center;
    margin: 15px 0;
}

a.btn.btn-primary.btn-block.via_whats {
    background: #25d366;
    border: #25d366;
}

</style>


<style>
       .info-call h5 {
    margin: 0;
    margin-bottom: 7px;
}

.info-call h6 {
    direction: ltr;
    color: red;
}

.whts {
   color: #25d366 !important;
}

#callusModal button.close {
    border: 0;
    border-radius: 13px;
}


   </style>




<style>
.btn-block {
    width: 100%;
    margin-top: 10px;
    padding: 12px;
}
center#headigoox h6 {
    text-align: center;
    margin-top: 13px;
    font-size: 25px;
}

center#headigoox {
    margin-top: 30px;
    margin-bottom: 43px;
}

center#headigoox .fas {
    color: #FFBD0C;
    font-size: 33px;
}

button.btn.btn-primary.btn-block {
    background: #ffbd0c;
    border: 0;
}

div#StartNow .close {
    border: 0;
    height: 28px;
    display: inline-block;
    overflow: hidden;
    padding: 0 !important;
    width: 28px !important;
    position: relative;
}

div#StartNow .close span {
    display: inline-block;
    height: 5px !important;
    line-height: 10px;
    position: relative;
    margin: 0 !important;
    position: absolute;
    margin-right: auto;
    left: 9px;
    top: 9px;
}

</style>

<style>
    .faq-accordion .accordion-button:after {
        margin-right: auto;
        margin-left: 0;
    }
    center#headigoox h6 {
        margin-bottom: 10px;
    }
    div#StartNow .close {
        margin-top: 10px;
        margin-right: 10px;
    }
    a.btn.btn-primary.btn-block.via_whats {
        margin-top: 0;
    }
    center#headigoox {
        margin: 10px 0;
    }
    button.close {
    background: transparent;
}

div#StartNow .close span {
    font-size: 30px;
    top: 5px;
    right: 0;
    height: initial !important;
    width: initial !important;
}
input, .form-control {
    padding: 15px;
    line-height: 18px !important;
    height: initial;
}

.col-form-label {
    margin-bottom: 1px !important;
}
</style>




<!-- Modal -->
<div class="modal fade" id="StartNow" tabindex="-1" role="dialog" dir="rtl" aria-labelledby="exampleModalLabel" aria-hidden="true">
   <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
      <div class="modal-content">

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        
         <div class="modal-body">
            <div class="step1">
               <center id="headigoox" class="text-center">
                  <i aria-hidden="true" class="fas fa-star"></i>
                  <h6> احجز مكالمتك الآن </h6>
                  <p class="text-center" > بعد ملأ هذه الإستمارة سيتصل بك أحد متخصصينا لتحديد طلبك في أقل من 3 ساعات</p>
               </center>
               <form action="javascript:;" id="call-to-action">
                  <div class="form-group row">
                     <label for="fullname" class="col-4 col-form-label">الإسم</label> 
                     <div class="col-12">
                        <input id="fullname" name="fullname" placeholder="الإسم الكامل" type="text" class="form-control" required="required">
                     </div>
                  </div>
                  <div class="form-group row">
                     <label class="col-4 col-form-label" for="text">رقم الهاتف</label> 
                     <div class="col-12">
                        <input id="phone" name="phone" placeholder="رقم الهاتف" type="number" class="form-control" required="required">
                     </div>
                  </div>

                  <div class="form-group row">
                     <label for="text2" class="col-4 col-form-label">  نوعية الفيديو </label> 
                     <div class="col-12">
                        <select name="service_type" id="service_type" class="form-control" >
                           <option value="منتج ايكوميرس" selected> منتج ايكوميرس </option>
                           <option value="مشروع أو شركة" > مشروع أو شركة </option>
                           <option value="موشن جرافيك" > موشن جرافيك </option>
                           <option value="منتج كوسميتيك" > منتج كوسميتيك </option>
                        </select>
                     </div>
                  </div>
                  <div class="form-group row">
                     <label class="col-4 col-form-label phone-wi" for="text"> ملاحضة (إختياري) </label> 
                     <div class="col-12">
                        <textarea name="note" id="note" class="form-control" cols="30" rows="3"></textarea>
                     </div>
                  </div>

                  <div class="form-group row">
                     <div class="col-12">
                        <button name="submit" type="submit" id='go_next' class="btn btn-primary btn-block"> إضغك هنا للتأكيد </button>
                        <p class="orrr" >أو </p>
                        <a href="https://wa.me/+212669420404" type="submit" class="btn btn-primary btn-block via_whats"> تواصل معنا مباشرة عبر الواتساب </a>
                     </div>
                  </div>
               </form>
            </div>
            <div class="step2" style='display:none;'>
               <center id="headigoox" class="text-center">
                  <i aria-hidden="true" class="fas fa-star"></i>
                  <h6>    تهــانينا </h6>
               </center>
               تم استلام طلبك بنجاح 
               <br>
               سيتم الرد عليك في أقرب وقت ممكن
               <br>
               شكراً لك
            </div>
         </div>
      </div>
   </div>
</div>
        
        
<footer class="footer-area">
    <div class="container">
        <div class="footer-top">
            <div class="footer-social-link">
                <ul class="list-unstyled">
                    <li><a href="https://www.facebook.com/mediaman.ma" data-sal="slide-up" data-sal-duration="500"
                            data-sal-delay="100"><i class="fab fa-facebook-f"></i></a></li>
                    <li><a href="https://www.instagram.com/mediaman.ma/" data-sal="slide-up" data-sal-duration="500"
                            data-sal-delay="500"><i class="fab fa-instagram"></i></a></li>
                    <li><a href="https://www.youtube.com/channel/UCugvyKeIu70AYEJnlCIWT0w" data-sal="slide-up" data-sal-duration="500" data-sal-delay="600"><i
                                class="fab fa-youtube"></i></a></li>
                   
                    
                    <li>
                        <a href="https://www.linkedin.com/company/media-man/" data-sal="slide-up" data-sal-duration="500"
                            data-sal-delay="800"><i class="fab fa-linkedin"></i></a></li>


                            
                </ul>
            </div>
        </div>
        <div class="footer-main">
            <div class="row">

                <div class="col-xl-6 col-lg-7 " data-sal="slide-left" data-sal-duration="800" data-sal-delay="100">
                    <div class="row">
                        <div class="col-sm-5 text-end">
                            <div class="footer-widget">
                                <h6 class="widget-title">خدماتنا</h6>
                                <div class="footer-menu-link">
                                    <ul class="list-unstyled">
                                        <li><a href="branding">بناء الهوية التجارية و التصميم</a></li>
                                        <li><a href="development-web">تصميم و برمجة المواقع </a></li>
                                        <li><a href="digital-advertising">الحملات الإعلانية</a></li>
                                        <li><a href="video-production">الفيديوهات التسويقية</a></li>
                                        <li><a href="social-media-managemet">ادارة مواقع التواصل الاجتماعي</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-3 text-end">
                            <div class="footer-widget">
                                <h6 class="widget-title">عن ميديا مان</h6>
                                <div class="footer-menu-link">
                                    <ul class="list-unstyled">
                                        <li><a href="about">من نحن</a></li>
                                        <!-- <li><a href="team">فريق ميديا مان</a></li> -->
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4 text-end ">
                            <div class="footer-widget">
                                <h6 class="widget-title"> تواصل معنا </h6>
                                <div class="footer-menu-link">
                                    <ul class="list-unstyled">
                                        <li><a href="contact">تواصل معنا</a></li>
                                        <li><a href="privacy-policy">سياسة الخصوصية</a></li>
                                        <li><a href="terms-of-use">شروط الإستخدام</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-xl-6 col-lg-5 footer-mediaman" data-sal="slide-bottom" data-sal-duration="800"
                    data-sal-delay="100">
                    <div class="footer-widget ">
                        <div class="footer-newsletter">
                            <h2 class="title">
                                <img class="light-version-logo" src="/assets/logo-01.png" alt="logo">
                            </h2>
                            <p style="direction: rtl;">
                                إن سمعتنا وجودة عملنا هما رأسمالنا الأهم، بل الوحيد. لذلك كن على ثقة تامة
                                <br> نأمل أن نتعاون في أقرب وقت . أنت في أيد أمينة.
                            </p>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom" data-sal="slide-up" data-sal-duration="500" data-sal-delay="100">
            <div class="row">
                <div class="col-md-12">
                    <div class="footer-copyright text-center">
                        <span class="copyright-text">© 2021. جميع الحقوق محفوظة <a
                                href="https://mediaman.ma/">Mediaman</a>.</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>

    </div>

    <!-- Jquery Js -->
<script data-cfasync="false" src="/cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
<script src="https://cdn.rtlcss.com/bootstrap/v4.2.1/js/bootstrap.min.js"></script>
<script src="assets/js/vendor/isotope.pkgd.min.js"></script>
<script src="assets/js/vendor/imagesloaded.pkgd.min.js"></script>
<script src="assets/js/vendor/waypoints.min.js"></script>
<script src="assets/js/vendor/counterup.js"></script>
<script src="assets/js/vendor/slick.min.js"></script>
<script src="assets/js/vendor/sal.js"></script>
<script src="assets/js/vendor/jquery.magnific-popup.min.js"></script>
<script src="assets/js/vendor/js.cookie.js"></script>
<script src="assets/js/vendor/jquery.style.switcher.js"></script>
<script src="assets/js/vendor/jquery.countdown.min.js"></script>
<script src="assets/js/vendor/tilt.js"></script>
<script src="assets/js/vendor/green-audio-player.min.js"></script>
<script src="assets/js/vendor/jquery.nav.js"></script>

<!-- Site Scripts -->
<script src="assets/js/app.js"></script>
<script src="assets/js/sheets.js"></script>

<script>

$('body .accordion-header button').click(function(){
  clean();
  var target = $(this).attr('data-bs-target');
  $(this).removeClass('collapsed');
  $(target).addClass('show');
});

function clean(){
  $('body .accordion-header button').each(function(){
    var target = $(this).attr('data-bs-target');
    $(this).addClass('collapsed');
    $(target).removeClass('show');
  });
}


function checkform(){
  var rem = true;
  $('.step1 input').each(function(){
      if( ! $(this).val() ) {
        rem = false;
      }
  });

  return rem;
}

$('#go_next').click(function(){
  
  if( checkform() ) {
    $('.step1').hide();
    $('.step2').show();
  }
  
});

</script>
</body>



</html>